#include "general.h"

SEXP cv_jtharm_fit(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP);
SEXP jt_harm_fit(SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP,SEXP);
int get_yu(double*,double*,double*,int,int,int*);
double get_df_jt(double*,double*,int,int,int*);
